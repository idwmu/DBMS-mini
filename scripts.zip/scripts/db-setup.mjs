// =====================================================================
// db-setup.mjs: One-command database provisioning
//   npm run db:setup            -> create DB (if missing), schema, logic, seed
//   npm run db:setup -- --no-seed
// Re-runnable: the schema file drops and recreates all tables.
// =====================================================================

import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import pg from 'pg';
import { resolveTimezone } from '../src/lib/timezone.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

for (const f of ['.env.local', '.env']) {
  const p = path.join(root, f);
  if (fs.existsSync(p)) process.loadEnvFile(p);
}

const url = process.env.DATABASE_URL;
if (!url) {
  console.error('DATABASE_URL is not set. Copy .env.example to .env.local and edit it.');
  process.exit(1);
}

const skipSeed = process.argv.includes('--no-seed');

const files = [
  'db/schema/001_schema.sql',
  'db/logic/001_views.sql',
  'db/logic/002_functions.sql',
  'db/logic/003_triggers.sql',
  ...(skipSeed ? [] : ['db/seed/seed.sql'])
];

async function ensureDatabase() {
  const target = new URL(url);
  const dbName = decodeURIComponent(target.pathname.replace(/^\//, ''));
  const adminUrl = new URL(url);
  adminUrl.pathname = '/postgres';

  const admin = new pg.Client({ connectionString: adminUrl.toString() });
  try {
    await admin.connect();
    const { rowCount } = await admin.query('SELECT 1 FROM pg_database WHERE datname = $1', [dbName]);
    if (rowCount === 0) {
      await admin.query(`CREATE DATABASE "${dbName.replace(/"/g, '""')}"`);
      console.log(`-> Created database "${dbName}"`);
    }
  } catch (err) {
    console.warn(`(Could not check/create database automatically: ${err.message})`);
  } finally {
    await admin.end().catch(() => {});
  }
}

async function main() {
  console.log('==========================================================');
  console.log('Initializing Student Workload & Deadline Collision Database');
  console.log(`Target: ${url.replace(/:\/\/([^:]+):[^@]*@/, '://$1:****@')}`);
  console.log('==========================================================');

  await ensureDatabase();

  const client = new pg.Client({ connectionString: url });
  await client.connect();
  try {
    const timezone = await resolveTimezone(client);
    await client.query(`SET TIME ZONE '${timezone}'`);
    console.log(`-> Session time zone: ${timezone}`);
    for (const [i, file] of files.entries()) {
      console.log(`-> ${i + 1}. Applying ${file}`);
      await client.query(fs.readFileSync(path.join(root, file), 'utf8'));
    }
  } finally {
    await client.end();
  }

  console.log('==========================================================');
  console.log('Database setup completed successfully.');
  console.log('Tables, views, functions, triggers' + (skipSeed ? '' : ' and seed data') + ' are in place.');
  console.log('==========================================================');
}

main().catch((err) => {
  console.error('\nDatabase setup failed:', err.message);
  if (err.where) console.error(err.where);
  process.exit(1);
});
