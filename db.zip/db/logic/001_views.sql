-- =====================================================================
-- 001_views.sql: Database Views
-- =====================================================================

DROP VIEW IF EXISTS v_student_task_overview;
DROP VIEW IF EXISTS v_high_risk_students;
DROP VIEW IF EXISTS v_course_risk_summary;
DROP VIEW IF EXISTS v_latest_workload;

-- ---------------------------------------------------------------------
-- 0. v_latest_workload:
-- The most recent WORKLOAD_ANALYSIS row per student (DISTINCT ON).
-- Reused by the other views and by the faculty risk queries.
-- ---------------------------------------------------------------------
CREATE VIEW v_latest_workload AS
SELECT DISTINCT ON (student_id) *
FROM workload_analysis
ORDER BY student_id, analysis_id DESC;

-- ---------------------------------------------------------------------
-- 1. v_student_task_overview:
-- Flat view joining students, courses, assigned tasks and progress.
-- Computes overdue status and hours-until-deadline dynamically.
-- ---------------------------------------------------------------------
CREATE VIEW v_student_task_overview AS
SELECT
    st.student_task_id,
    s.student_id,
    s.roll_no,
    u.username              AS student_name,
    u.email                 AS student_email,
    s.program,
    s.semester              AS student_semester,
    s.section,
    c.course_id,
    c.course_code,
    c.course_name,
    c.faculty_id,
    fu.username             AS faculty_name,
    t.task_id,
    t.title                 AS task_title,
    t.description           AS task_description,
    t.task_type,
    t.release_datetime,
    t.deadline_datetime,
    t.estimated_hours,
    t.difficulty_level,
    t.cognitive_load,
    t.assessment_weight,
    t.is_team_task,
    t.status                AS task_status,
    st.assigned_at,
    st.status               AS submission_status,
    st.actual_hours,
    st.completion_percentage,
    st.submitted_at,
    st.score,
    (t.deadline_datetime < NOW()
        AND (st.completion_percentage < 100 OR st.status <> 'completed')) AS is_overdue,
    TRUNC(EXTRACT(EPOCH FROM (t.deadline_datetime - NOW())) / 3600)::INT   AS hours_until_deadline
FROM student_tasks st
JOIN students s  ON st.student_id = s.student_id
JOIN users u     ON s.user_id = u.user_id
JOIN tasks t     ON st.task_id = t.task_id
JOIN courses c   ON t.course_id = c.course_id
LEFT JOIN users fu ON c.faculty_id = fu.user_id;

-- ---------------------------------------------------------------------
-- 2. v_course_risk_summary:
-- Course metrics, enrolled students (matching semester), average task
-- completion, and average latest student risk score.
-- ---------------------------------------------------------------------
CREATE VIEW v_course_risk_summary AS
SELECT
    c.course_id,
    c.course_code,
    c.course_name,
    c.credits,
    c.semester,
    c.faculty_id,
    fu.username AS faculty_name,
    COUNT(DISTINCT t.task_id)::INT    AS total_tasks,
    COUNT(DISTINCT s.student_id)::INT AS total_enrolled_students,
    COALESCE(ROUND(AVG(st.completion_percentage), 2), 0.00)  AS avg_completion_percentage,
    COALESCE(ROUND(AVG(lw.overall_risk_score), 2), 0.00)     AS avg_student_risk_score,
    COUNT(DISTINCT CASE WHEN lw.risk_level IN ('HIGH', 'CRITICAL') THEN s.student_id END)::INT
                                                             AS high_risk_student_count
FROM courses c
LEFT JOIN users fu          ON c.faculty_id = fu.user_id
LEFT JOIN tasks t           ON c.course_id = t.course_id
LEFT JOIN students s        ON s.semester = c.semester
LEFT JOIN student_tasks st  ON st.task_id = t.task_id AND st.student_id = s.student_id
LEFT JOIN v_latest_workload lw ON lw.student_id = s.student_id
GROUP BY c.course_id, c.course_code, c.course_name, c.credits,
         c.semester, c.faculty_id, fu.username;

-- ---------------------------------------------------------------------
-- 3. v_high_risk_students:
-- Students whose latest analysis is HIGH or CRITICAL, with counts of
-- unresolved collisions and pending tasks.
-- ---------------------------------------------------------------------
CREATE VIEW v_high_risk_students AS
SELECT
    s.student_id,
    s.user_id,
    u.username   AS student_name,
    u.email      AS student_email,
    s.roll_no,
    s.program,
    s.semester,
    s.section,
    adv.username AS advisor_name,
    wa.analysis_id,
    wa.total_estimated_hours,
    wa.available_hours,
    wa.temporal_pressure,
    wa.workload_pressure,
    wa.cognitive_pressure,
    wa.assessment_pressure,
    wa.dependency_pressure,
    wa.overall_risk_score,
    wa.risk_level,
    wa.calculated_at,
    (SELECT COUNT(*) FROM collisions col
      WHERE col.student_id = s.student_id AND col.resolved = FALSE)::INT AS active_collisions_count,
    (SELECT COUNT(*) FROM student_tasks st2
       JOIN tasks t2 ON st2.task_id = t2.task_id
      WHERE st2.student_id = s.student_id
        AND st2.status <> 'completed'
        AND t2.deadline_datetime >= NOW())::INT                         AS pending_tasks_count
FROM students s
JOIN users u               ON s.user_id = u.user_id
LEFT JOIN users adv        ON s.advisor_id = adv.user_id
JOIN v_latest_workload wa  ON wa.student_id = s.student_id
WHERE wa.overall_risk_score >= 55.00 OR wa.risk_level IN ('HIGH', 'CRITICAL');
