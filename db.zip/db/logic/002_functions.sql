-- =====================================================================
-- 002_functions.sql: Workload & Collision Engine (PL/pgSQL)
--
-- These are the PostgreSQL ports of the original MySQL stored procedures.
-- They keep the same names (sp_*) so documentation and viva notes still
-- apply; in PostgreSQL they are FUNCTIONS invoked with SELECT, which lets
-- them RETURN the row they persist.
--
-- Note on arithmetic: MySQL rounds intermediate DECIMAL division to
-- (scale + 4) digits. The ROUND(..., n) calls around divisions below
-- reproduce that so scores match the original implementation exactly.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. sp_calculate_workload(student_id, start_dt, end_dt)
-- Five dimensional pressures and a weighted overall risk score:
--   Temporal   (25%): deadline density (deadlines per week)
--   Workload   (30%): remaining required hours / available hours
--   Cognitive  (15%): avg(cognitive_load x difficulty_level)
--   Assessment (20%): sum of assessment weights due
--   Dependency (10%): unfinished prerequisites (25 pts each)
-- Risk levels: LOW < 30 <= MEDIUM < 55 <= HIGH < 75 <= CRITICAL
-- Inserts and returns a WORKLOAD_ANALYSIS row.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_calculate_workload(
    p_student_id INT,
    p_start_dt   TIMESTAMPTZ DEFAULT NULL,
    p_end_dt     TIMESTAMPTZ DEFAULT NULL
) RETURNS workload_analysis
LANGUAGE plpgsql AS $$
DECLARE
    v_window_days          INT := 14;
    v_total_tasks          INT := 0;
    v_total_estimated      NUMERIC(7,2) := 0;
    v_logged_hours         NUMERIC(7,2) := 0;
    v_available_hours      NUMERIC(7,2) := 0;
    v_effective_available  NUMERIC(7,2) := 1;
    v_raw_cog_diff         NUMERIC(7,2) := 0;
    v_raw_weight           NUMERIC(7,2) := 0;
    v_unfinished_prereqs   INT := 0;

    v_temporal    NUMERIC(5,2) := 0;
    v_workload    NUMERIC(5,2) := 0;
    v_cognitive   NUMERIC(5,2) := 0;
    v_assessment  NUMERIC(5,2) := 0;
    v_dependency  NUMERIC(5,2) := 0;
    v_overall     NUMERIC(5,2) := 0;
    v_risk_level  VARCHAR(30)  := 'LOW';

    v_row workload_analysis;
BEGIN
    -- Normalize date window defaults
    p_start_dt := COALESCE(p_start_dt, NOW());
    p_end_dt   := COALESCE(p_end_dt, p_start_dt + INTERVAL '14 days');

    v_window_days := GREATEST(1, p_end_dt::date - p_start_dt::date);

    -- Uncompleted tasks due in window
    SELECT
        COUNT(*),
        COALESCE(SUM(COALESCE(t.estimated_hours, 5.00)
                     * (1.00 - ROUND(COALESCE(st.completion_percentage, 0) / 100.00, 6))), 0),
        COALESCE(AVG(COALESCE(t.cognitive_load, 3) * COALESCE(t.difficulty_level, 3)), 0),
        COALESCE(SUM(COALESCE(t.assessment_weight, 0)), 0)
    INTO v_total_tasks, v_total_estimated, v_raw_cog_diff, v_raw_weight
    FROM student_tasks st
    JOIN tasks t ON st.task_id = t.task_id
    WHERE st.student_id = p_student_id
      AND st.status <> 'completed'
      AND st.completion_percentage < 100
      AND t.deadline_datetime BETWEEN p_start_dt AND p_end_dt;

    -- Logged availability overlapping the window
    SELECT COALESCE(SUM(available_hours), 0)
    INTO v_logged_hours
    FROM availability
    WHERE student_id = p_student_id
      AND start_datetime < p_end_dt
      AND end_datetime   > p_start_dt;

    -- Use logged hours if any; otherwise assume a 4 hour/day baseline
    IF v_logged_hours > 0 THEN
        v_available_hours := v_logged_hours;
    ELSE
        v_available_hours := v_window_days * 4.00;
    END IF;
    v_effective_available := GREATEST(1.00, v_available_hours);

    -- 1. Temporal: deadlines/week; 5 per week = 100
    v_temporal := LEAST(100.00, ROUND(ROUND(v_total_tasks::NUMERIC / v_window_days, 4) * 7.00 * 20.00, 2));

    -- 2. Workload: required hours vs available hours
    v_workload := LEAST(100.00, ROUND(ROUND(v_total_estimated / v_effective_available, 6) * 100.00, 2));

    -- 3. Cognitive: avg(cog 1-10 x diff 1-5), max product 50 scaled to 100
    v_cognitive := LEAST(100.00, ROUND(ROUND(v_raw_cog_diff / 50.00, 6) * 100.00, 2));

    -- 4. Assessment: sum of grade weights due in window
    v_assessment := LEAST(100.00, ROUND(v_raw_weight, 2));

    -- 5. Dependency: unfinished prerequisites for tasks due in window
    SELECT COUNT(*)
    INTO v_unfinished_prereqs
    FROM task_dependencies td
    JOIN student_tasks st_due ON td.task_id = st_due.task_id
    JOIN tasks t_due          ON st_due.task_id = t_due.task_id
    LEFT JOIN student_tasks st_pre
           ON td.prerequisite_task_id = st_pre.task_id
          AND st_pre.student_id = p_student_id
    WHERE st_due.student_id = p_student_id
      AND st_due.status <> 'completed'
      AND st_due.completion_percentage < 100
      AND t_due.deadline_datetime BETWEEN p_start_dt AND p_end_dt
      AND (st_pre.student_task_id IS NULL
           OR st_pre.status <> 'completed'
           OR st_pre.completion_percentage < 100);

    v_dependency := LEAST(100.00, ROUND(v_unfinished_prereqs * 25.00, 2));

    -- Weighted overall score
    v_overall := LEAST(100.00, ROUND(
          0.25 * v_temporal
        + 0.30 * v_workload
        + 0.15 * v_cognitive
        + 0.20 * v_assessment
        + 0.10 * v_dependency, 2));

    v_risk_level := CASE
        WHEN v_overall < 30.00 THEN 'LOW'
        WHEN v_overall < 55.00 THEN 'MEDIUM'
        WHEN v_overall < 75.00 THEN 'HIGH'
        ELSE 'CRITICAL'
    END;

    INSERT INTO workload_analysis (
        student_id, start_datetime, end_datetime,
        total_estimated_hours, available_hours,
        temporal_pressure, workload_pressure, cognitive_pressure,
        assessment_pressure, dependency_pressure,
        overall_risk_score, risk_level, calculated_at
    ) VALUES (
        p_student_id, p_start_dt, p_end_dt,
        v_total_estimated, v_available_hours,
        v_temporal, v_workload, v_cognitive,
        v_assessment, v_dependency,
        v_overall, v_risk_level, NOW()
    )
    RETURNING * INTO v_row;

    RETURN v_row;
END;
$$;


-- ---------------------------------------------------------------------
-- 2. sp_detect_collisions(student_id)
--   DEADLINE_CLUSTER:   3+ uncompleted deadlines within any 48h window
--   OVERLOAD:           required hours > available hours (latest analysis)
--   ASSESSMENT_OVERLAP: 2+ assessments within 24h with total weight >= 25%
-- Never duplicates an unresolved collision of the same type/date.
-- Returns the number of new collisions inserted.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_detect_collisions(p_student_id INT)
RETURNS INT
LANGUAGE plpgsql AS $$
DECLARE
    v_latest_analysis_id INT;
    v_total_est          NUMERIC(7,2) := 0;
    v_avail_hours        NUMERIC(7,2) := 0;

    rec                  RECORD;
    v_cluster_count      INT;
    v_overlap_count      INT;
    v_overlap_weight     NUMERIC(7,2);
    v_date_str           TEXT;
    v_inserted           INT := 0;
BEGIN
    -- Latest workload analysis for reference
    SELECT analysis_id, total_estimated_hours, available_hours
    INTO v_latest_analysis_id, v_total_est, v_avail_hours
    FROM workload_analysis
    WHERE student_id = p_student_id
    ORDER BY calculated_at DESC, analysis_id DESC
    LIMIT 1;

    v_total_est   := COALESCE(v_total_est, 0);
    v_avail_hours := COALESCE(v_avail_hours, 0);

    -- CHECK 1: OVERLOAD
    IF v_total_est > v_avail_hours AND v_total_est > 0 THEN
        IF NOT EXISTS (
            SELECT 1 FROM collisions
            WHERE student_id = p_student_id
              AND collision_type = 'OVERLOAD'
              AND resolved = FALSE
        ) THEN
            INSERT INTO collisions (student_id, analysis_id, collision_type, severity, description, detected_at, resolved)
            VALUES (
                p_student_id,
                v_latest_analysis_id,
                'OVERLOAD',
                CASE WHEN v_total_est >= 1.50 * v_avail_hours THEN 'HIGH' ELSE 'MEDIUM' END,
                'Workload overload: ' || v_total_est || ' required task hours exceed '
                    || v_avail_hours || ' available study hours in next 14 days.',
                NOW(),
                FALSE
            );
            v_inserted := v_inserted + 1;
        END IF;
    END IF;

    -- CHECK 2 & 3: walk future uncompleted deadlines in order
    FOR rec IN
        SELECT t.task_id, t.deadline_datetime, t.title
        FROM student_tasks st
        JOIN tasks t ON st.task_id = t.task_id
        WHERE st.student_id = p_student_id
          AND st.status <> 'completed'
          AND st.completion_percentage < 100
          AND t.deadline_datetime >= NOW()
        ORDER BY t.deadline_datetime ASC
    LOOP
        v_date_str := to_char(rec.deadline_datetime, 'YYYY-MM-DD');

        -- Deadlines within 48h starting at this one
        SELECT COUNT(*)
        INTO v_cluster_count
        FROM student_tasks st2
        JOIN tasks t2 ON st2.task_id = t2.task_id
        WHERE st2.student_id = p_student_id
          AND st2.status <> 'completed'
          AND st2.completion_percentage < 100
          AND t2.deadline_datetime >= rec.deadline_datetime
          AND t2.deadline_datetime <= rec.deadline_datetime + INTERVAL '48 hours';

        IF v_cluster_count >= 3 AND NOT EXISTS (
            SELECT 1 FROM collisions
            WHERE student_id = p_student_id
              AND collision_type = 'DEADLINE_CLUSTER'
              AND resolved = FALSE
              AND description LIKE '%' || v_date_str || '%'
        ) THEN
            INSERT INTO collisions (student_id, analysis_id, collision_type, severity, description, detected_at, resolved)
            VALUES (
                p_student_id,
                v_latest_analysis_id,
                'DEADLINE_CLUSTER',
                CASE WHEN v_cluster_count >= 4 THEN 'HIGH' ELSE 'MEDIUM' END,
                'Deadline cluster detected: ' || v_cluster_count
                    || ' deadlines fall within 48 hours starting at '
                    || to_char(rec.deadline_datetime, 'YYYY-MM-DD HH24:MI'),
                NOW(),
                FALSE
            );
            v_inserted := v_inserted + 1;
        END IF;

        -- Assessments within 24h starting at this one
        SELECT COUNT(*), COALESCE(SUM(t3.assessment_weight), 0)
        INTO v_overlap_count, v_overlap_weight
        FROM student_tasks st3
        JOIN tasks t3 ON st3.task_id = t3.task_id
        WHERE st3.student_id = p_student_id
          AND st3.status <> 'completed'
          AND st3.completion_percentage < 100
          AND t3.deadline_datetime >= rec.deadline_datetime
          AND t3.deadline_datetime <= rec.deadline_datetime + INTERVAL '24 hours';

        IF v_overlap_count >= 2 AND v_overlap_weight >= 25.00 AND NOT EXISTS (
            SELECT 1 FROM collisions
            WHERE student_id = p_student_id
              AND collision_type = 'ASSESSMENT_OVERLAP'
              AND resolved = FALSE
              AND description LIKE '%' || v_date_str || '%'
        ) THEN
            INSERT INTO collisions (student_id, analysis_id, collision_type, severity, description, detected_at, resolved)
            VALUES (
                p_student_id,
                v_latest_analysis_id,
                'ASSESSMENT_OVERLAP',
                'HIGH',
                'High assessment collision: ' || v_overlap_count
                    || ' assessments totalling ' || v_overlap_weight
                    || '% of course grades due within 24 hours of '
                    || to_char(rec.deadline_datetime, 'YYYY-MM-DD HH24:MI'),
                NOW(),
                FALSE
            );
            v_inserted := v_inserted + 1;
        END IF;
    END LOOP;

    RETURN v_inserted;
END;
$$;


-- ---------------------------------------------------------------------
-- 3. sp_assign_task_to_students(task_id)
-- Assigns a task to every student in the course's semester.
-- Returns the number of new assignments.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_assign_task_to_students(p_task_id INT)
RETURNS INT
LANGUAGE plpgsql AS $$
DECLARE
    v_course_semester INT;
    v_count INT;
BEGIN
    SELECT c.semester
    INTO v_course_semester
    FROM tasks t
    JOIN courses c ON t.course_id = c.course_id
    WHERE t.task_id = p_task_id;

    INSERT INTO student_tasks (student_id, task_id, assigned_at, status, actual_hours, completion_percentage)
    SELECT s.student_id, p_task_id, NOW(), 'assigned', 0.00, 0.00
    FROM students s
    WHERE s.semester = v_course_semester
    ON CONFLICT (student_id, task_id) DO NOTHING;

    GET DIAGNOSTICS v_count = ROW_COUNT;
    RETURN v_count;
END;
$$;


-- ---------------------------------------------------------------------
-- 4. sp_simulate_deadline_change(task_id, proposed_deadline, faculty_id)
-- Evaluates moving a task deadline WITHOUT touching the task itself.
-- Compares cohort risk and collisions, records a SIMULATIONS row with a
-- recommendation, and returns it.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_simulate_deadline_change(
    p_task_id           INT,
    p_proposed_deadline TIMESTAMPTZ,
    p_faculty_id        INT
) RETURNS simulations
LANGUAGE plpgsql AS $$
DECLARE
    v_course_semester      INT;
    v_original_deadline    TIMESTAMPTZ;
    v_affected_students    INT := 0;
    v_original_risk        NUMERIC(5,2) := 0;
    v_projected_risk       NUMERIC(5,2) := 0;
    v_original_collisions  INT := 0;
    v_projected_collisions INT := 0;
    v_impact_score         NUMERIC(5,2) := 0;
    v_recommendation       VARCHAR(255);
    v_orig_clusters        INT := 0;
    v_proj_clusters        INT := 0;
    v_row                  simulations;
BEGIN
    SELECT c.semester, t.deadline_datetime
    INTO v_course_semester, v_original_deadline
    FROM tasks t
    JOIN courses c ON t.course_id = c.course_id
    WHERE t.task_id = p_task_id;

    IF NOT FOUND THEN
        RAISE EXCEPTION 'Task % does not exist', p_task_id;
    END IF;

    SELECT COUNT(DISTINCT s.student_id)
    INTO v_affected_students
    FROM students s
    WHERE s.semester = v_course_semester;

    -- Baseline: average latest risk + unresolved collisions for the cohort
    SELECT
        COALESCE(ROUND(AVG(lw.overall_risk_score), 2), 35.00),
        COALESCE(SUM(cc.unresolved_count), 0)
    INTO v_original_risk, v_original_collisions
    FROM students s
    LEFT JOIN v_latest_workload lw ON lw.student_id = s.student_id
    LEFT JOIN (
        SELECT student_id, COUNT(*) AS unresolved_count
        FROM collisions
        WHERE resolved = FALSE
        GROUP BY student_id
    ) cc ON cc.student_id = s.student_id
    WHERE s.semester = v_course_semester;

    -- Other same-semester tasks within +/-48h of the ORIGINAL deadline
    SELECT COUNT(*)
    INTO v_orig_clusters
    FROM tasks t2
    JOIN courses c2 ON t2.course_id = c2.course_id
    WHERE c2.semester = v_course_semester
      AND t2.task_id <> p_task_id
      AND t2.deadline_datetime BETWEEN v_original_deadline - INTERVAL '48 hours'
                                   AND v_original_deadline + INTERVAL '48 hours';

    -- Other same-semester tasks within +/-48h of the PROPOSED deadline
    SELECT COUNT(*)
    INTO v_proj_clusters
    FROM tasks t3
    JOIN courses c3 ON t3.course_id = c3.course_id
    WHERE c3.semester = v_course_semester
      AND t3.task_id <> p_task_id
      AND t3.deadline_datetime BETWEEN p_proposed_deadline - INTERVAL '48 hours'
                                   AND p_proposed_deadline + INTERVAL '48 hours';

    -- Moving into a cluster raises risk 15 pts per extra clashing task
    v_projected_risk := LEAST(100.00, GREATEST(5.00, ROUND(
        v_original_risk + (v_proj_clusters - v_orig_clusters) * 15.00, 2)));

    v_projected_collisions := GREATEST(0,
        v_original_collisions + (v_proj_clusters - v_orig_clusters) * GREATEST(1, v_affected_students));

    v_impact_score := ROUND(v_projected_risk - v_original_risk, 2);

    IF v_impact_score <= -5.00 THEN
        v_recommendation := 'APPROVE: Shifting deadline relieves pressure and resolves deadline collisions.';
    ELSIF v_impact_score <= 4.00 AND v_proj_clusters < 2 THEN
        v_recommendation := 'APPROVE: Proposed deadline maintains a balanced workload with negligible impact.';
    ELSIF v_proj_clusters >= 2 OR v_impact_score >= 15.00 THEN
        v_recommendation := 'NOT RECOMMENDED: Severe collision cluster created with 3+ overlapping tasks.';
    ELSE
        v_recommendation := 'SUGGEST ALTERNATE DATE: Moderate risk increase; consider postponing by 2 to 3 days.';
    END IF;

    INSERT INTO simulations (
        faculty_id, task_id, original_deadline, proposed_deadline,
        affected_students, original_risk, projected_risk,
        original_collisions, projected_collisions,
        impact_score, recommendation, created_at
    ) VALUES (
        p_faculty_id, p_task_id, v_original_deadline, p_proposed_deadline,
        v_affected_students, v_original_risk, v_projected_risk,
        v_original_collisions, v_projected_collisions,
        v_impact_score, v_recommendation, NOW()
    )
    RETURNING * INTO v_row;

    RETURN v_row;
END;
$$;


-- ---------------------------------------------------------------------
-- 5. sp_refresh_student(student_id)
-- Convenience wrapper: recalculate the default 14-day window and then
-- detect collisions. Used after every mutation that affects a student.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION sp_refresh_student(p_student_id INT)
RETURNS VOID
LANGUAGE plpgsql AS $$
BEGIN
    PERFORM sp_calculate_workload(p_student_id, NOW(), NOW() + INTERVAL '14 days');
    PERFORM sp_detect_collisions(p_student_id);
END;
$$;
