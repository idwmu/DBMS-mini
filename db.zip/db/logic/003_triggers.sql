-- =====================================================================
-- 003_triggers.sql: Integrity & Workload Sync Triggers (PL/pgSQL)
-- =====================================================================

-- ---------------------------------------------------------------------
-- (a) trg_prevent_circular_dependencies
-- BEFORE INSERT OR UPDATE ON task_dependencies
-- Walks the prerequisite chain of the new prerequisite with a recursive
-- CTE and rejects the row if it would close a cycle (A -> B -> C -> A).
-- Self-dependency is already blocked by CHECK (task_id <> prerequisite_task_id).
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_prevent_circular_dependencies()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
DECLARE
    v_cycle_detected INT := 0;
BEGIN
    WITH RECURSIVE prereq_path AS (
        SELECT td.prerequisite_task_id
        FROM task_dependencies td
        WHERE td.task_id = NEW.prerequisite_task_id

        UNION

        SELECT td.prerequisite_task_id
        FROM task_dependencies td
        JOIN prereq_path pp ON td.task_id = pp.prerequisite_task_id
    )
    SELECT COUNT(*)
    INTO v_cycle_detected
    FROM prereq_path
    WHERE prerequisite_task_id = NEW.task_id;

    IF v_cycle_detected > 0 THEN
        RAISE EXCEPTION 'Circular dependency detected: Prerequisite chain cannot form a cycle.'
            USING ERRCODE = 'P0001';
    END IF;

    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_prevent_circular_dependencies ON task_dependencies;
CREATE TRIGGER trg_prevent_circular_dependencies
BEFORE INSERT OR UPDATE OF task_id, prerequisite_task_id ON task_dependencies
FOR EACH ROW EXECUTE FUNCTION fn_prevent_circular_dependencies();


-- ---------------------------------------------------------------------
-- (b) trg_tasks_deadline_check
-- BEFORE INSERT OR UPDATE ON tasks
-- deadline_datetime must be strictly after release_datetime.
-- (Replaces the separate _insert / _update triggers of the MySQL version.)
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_tasks_deadline_check()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
    IF NEW.release_datetime IS NOT NULL AND NEW.deadline_datetime <= NEW.release_datetime THEN
        RAISE EXCEPTION 'Invalid task dates: deadline_datetime must be strictly after release_datetime.'
            USING ERRCODE = 'P0001';
    END IF;
    RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS trg_tasks_deadline_check ON tasks;
CREATE TRIGGER trg_tasks_deadline_check
BEFORE INSERT OR UPDATE ON tasks
FOR EACH ROW EXECUTE FUNCTION fn_tasks_deadline_check();


-- ---------------------------------------------------------------------
-- (c) trg_student_tasks_after_insert
-- AFTER INSERT ON student_tasks
-- Re-computes workload and re-evaluates collisions for the student
-- whenever a task is assigned. Skip during bulk maintenance with:
--     SET app.disable_triggers = '1';
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION fn_student_tasks_after_insert()
RETURNS TRIGGER
LANGUAGE plpgsql AS $$
BEGIN
    IF COALESCE(current_setting('app.disable_triggers', true), '0') <> '1' THEN
        PERFORM sp_calculate_workload(NEW.student_id, NOW(), NOW() + INTERVAL '14 days');
        PERFORM sp_detect_collisions(NEW.student_id);
    END IF;
    RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_student_tasks_after_insert ON student_tasks;
CREATE TRIGGER trg_student_tasks_after_insert
AFTER INSERT ON student_tasks
FOR EACH ROW EXECUTE FUNCTION fn_student_tasks_after_insert();
